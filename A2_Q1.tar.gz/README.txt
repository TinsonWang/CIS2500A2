CIS2500 Assignment 2 - Due: February 3, 2020
Written by Tinson Wang, 0983887

Files included in this program:
1. a2_q1.c
2. double_array.c
3. rand_double.c
4. randomize_array.c
5. print_array.c
6. free_array.c
7. swap_rows.c
8. swap_columns.c
9. functions.h
10. Makefile
11. README.txt

Q1a.
The name of an array variable can also be interpreted as the address of the first element of the array. In other words,
&array[0]. So when a pointer is set equal to the name of the array, it will point to the first element of that array.
Because elements in an array are stored in memory back-to-back, the pointer effectively becomes able to reference each
and every element of that array. Therefore, it is sufficient to only just use the names of the array for the swap.
Without using a for loop, this would be considered the "fast" approach.

Q2b.
The "fast" approach from before cannot be applied here because the elements in a column are not located in memory in the same
way the elements in a row of an array are. They are not contiguous. In other words, they are stored in a way such that the
elements within a column are not back-to-back. Therefore the logic from before does not work. The other way to perform a column
swap would thus be to use a for loop: iterating, copying, and swapping each element, one by one.
