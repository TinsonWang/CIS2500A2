#include <assert.h>
#include "functions.h"

int swap_rows (Double_Array* ptr, int row1, int row2)
{
    if ( (row1 <= ptr->rowsize) && (row2 <= ptr->rowsize) )
    {
        /*Decrement input because these variables will be used as indices*/
        row1--;
        row2--;

        int size = ptr->colsize;

        /*Create a new pointer to hold a row to be swapped*/
        double* temp_row[size];

        /*The name of an array also acts as the address to the first element of that array
            First set a pointer of an equivalent size to point to the address of the first element of that row
            This will allow the temporary pointer to be capable of referencing every element of that row without having to use a for loop.
            This is made possible because of the contiguous nature of how memory is stored for arrays */
        temp_row[0] = ptr->array[row1];

        /*Continue with the swap, again only using just the name of the array*/
        ptr->array[row1] = ptr->array[row2];
        ptr->array[row2] = temp_row[0];

        return 1;
    }
    else
    {
        return 0;
    }

}