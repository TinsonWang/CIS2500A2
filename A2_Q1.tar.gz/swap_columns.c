#include <assert.h>
#include "functions.h"

int swap_columns(Double_Array* ptr, int col1, int col2)
{
    if ( (col1 <= ptr->colsize) && (col2 <= ptr->colsize) )
    {
        /*Decrement input because these variables will be used as indices*/
        col1--;
        col2--;

        int size = ptr->rowsize;

        /*Create a new array to hold a column
            A pointer is not created here because the previous logic of using just the name of an array cannot be applied here*/
        double temp_col[size];

        /*Because of how a 2D array is arranged, elements within a column are not stored in memory back-to-back (ie, not contiguous)
            Therefore, cannot use the "fast" approach from swap_rows.c
            The only other way is to use a for loop to iterate, copy, and swap each element, one by one*/
        int i;
        for (i = 0; i < ptr->rowsize; i++)
        {
            temp_col[i] = ptr->array[i][col1];
            ptr->array[i][col1] = ptr->array[i][col2];
            ptr->array[i][col2] = temp_col[i];
        }

        return 1;
    }
    else
    {
        return 0;

    }


}