#include <assert.h>
#include "functions.h"


void randomize_array(Double_Array* ptr, double num1, double num2)
{
    /*Generate a random integer at each element in the array*/
    int i, j;
    for (i = 0; i < ptr->rowsize; i++)
    {
        for (j = 0; j < ptr->colsize; j++)
        {
            ptr->array[i][j] = rand_double(num1, num2);
        }
    }
}