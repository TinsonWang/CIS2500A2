#include <time.h>
#include "functions.h"

/*Generates a random number between a and b, inclusive*/
/*Reused from CIS2500 Lab 2*/
double rand_double(double a, double b)
{
    /*srand() sets the starting point for rand(). If srand() is not called, the default rand() seed is set using srand(1).*/
    /*srand (time(0));*/

    double c;

    if (b > a)
    {
        c = (((double) rand() / (double) RAND_MAX) * (b-a)) + a;
    }
    else if (b < a)
    {
        c = (((double) rand() / (double) RAND_MAX) * (a-b)) + b;
    }

    return c;
}