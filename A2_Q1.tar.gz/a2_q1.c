#include <assert.h>
#include "functions.h"

int main(int argc, char const *argv[])
{
    Double_Array* array = NULL;
    array = double_array(6, 9);
    randomize_array(array, 1, 5);
    print_array(array);

    int row1, row2;
    row1 = (int) rand_double(1, 6);
    row2 = (int) rand_double(1, 6);
    while (row1 == row2)
    {
        row2 = (int) rand_double(1, 6);
    }
    printf("Rows %d and %d will be swapped: \n", row1, row2);
    swap_rows(array, row1, row2);
    print_array(array);

    int col1, col2;
    col1 = (int) rand_double(1, 9);
    col2 = (int) rand_double(1, 9);
    while (col1 == col2)
    {
        col2 = (int) rand_double(1, 9);
    }
    printf("Columns %d and %d will be swapped: \n", col1, col2);
    swap_columns(array, col1, col2);
    print_array(array);

    printf("\n\n\n");

    free_array(array);

    return 0;
}
