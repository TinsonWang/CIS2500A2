#include "functions.h"

void free_array(Double_Array* ptr)
{
    int i = 0;
    for (i = 0; i < ptr->rowsize; i++)
    {
        free(ptr->array[i]);
    }
    /*while (ptr->array[i] != NULL)
    {

        free(ptr->array[i++]);
    }
    free(ptr->array[i]);*/
    free(ptr->array);
    free(ptr);
}