#include <assert.h>
#include "functions.h"

Double_Array* double_array(int row, int col)
{
    Double_Array* ptr = NULL;
    ptr = malloc(sizeof(Double_Array));
    assert(ptr != NULL);

    ptr->rowsize = row;
    ptr->colsize = col;

    /*The array will hold a total size of: */
    ptr->array = malloc(sizeof(double*) * row);
    assert(ptr->array != NULL);

    /*At each element of the array, create another array of size: */
    int i;
    for (i = 0; i < row; i++)
    {
        ptr->array[i] = malloc(sizeof(double) * col);
    }


    return  ptr;
}