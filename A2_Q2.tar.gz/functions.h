#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXBUFFER 500


typedef struct Double_Array
{
    int rowsize;
    int colsize;
    double** array;
}
Double_Array;

Double_Array* double_array(int row, int col);
double rand_double(double a, double b);
void randomize_array(Double_Array* array, double num1, double num2);
void print_array(Double_Array* ptr);
void free_array(Double_Array* ptr);
int swap_rows (Double_Array* ptr, int row1, int row2);
int swap_columns(Double_Array* ptr, int col1, int col2);
Double_Array* shallow_copy(Double_Array* ptr);
Double_Array* deep_copy (Double_Array* ptr);
void print_struct(Double_Array* ptr, char* string);



