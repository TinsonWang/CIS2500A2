#include "functions.h"

void print_array(Double_Array* ptr)
{
    int i, j;
    /*printf("rowsize: %d\n", ptr->rowsize);
    printf("colsize: %d\n", ptr->colsize);*/
    /*Double nested loop iterates and prints through each of the element in the array*/
    /*printf("Struct: %p  Array: %p\n", &ptr, &ptr->array);*/
    for (i = 0; i < ptr->rowsize; i++)
    {
        for (j = 0; j < ptr->colsize; j++)
        {
            printf("%06.1f ", ptr->array[i][j]);
        }
        printf("\n");
    }

    printf("\n");
}