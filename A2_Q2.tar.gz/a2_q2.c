#include <assert.h>
#include "functions.h"

int main(int argc, char const *argv[])
{
    printf("------------------------------------\n          Question 2a     \n------------------------------------\n\n");
    Double_Array* a1 = NULL;
    a1 = double_array(6, 9);
    randomize_array(a1, 0.0, 10.0);
    printf("The address of a1 is %p\n", &a1);
    print_struct(a1, "The structure pointed to by a1 is:");

    /*Same struct and same array address*/
    Double_Array* a2;
    a2 = a1;
    printf("The address of a2 is %p\n", &a2);
    print_struct(a2, "The structure pointed to by a2 is:");

    /*Different struct, but same array address*/
    Double_Array* a_shallow = NULL;
    a_shallow = shallow_copy(a1);
    printf("The address of a_shallow is %p\n", &a_shallow);
    print_struct(a_shallow, "The structure pointed to by a_shallow is:");

    /*Different struct and different array address*/
    Double_Array* a_deep = NULL;
    a_deep = deep_copy(a1);
    printf("The address of a_deep is %p\n", &a_deep);
    print_struct(a_deep, "The structure pointed to by a_deep is:");

    printf("\n\n\n");

    printf("------------------------------------\n          Question 2b     \n------------------------------------\n\n");

    a1->array[0][1] = 100.0;
    a2->array[1][2] = 200.0;
    a_shallow->array[2][3] = 300.0;
    a_deep->array[3][4] = 400.0;

    print_array(a1);
    print_array(a2);
    print_array(a_shallow);
    print_array(a_deep);

    printf("\n\n\n");

    printf("------------------------------------\n          Question 2c     \n------------------------------------\n\n");

    Double_Array* b1 = NULL;
    b1 = double_array(6, 9);
    randomize_array(b1, 10.0, 20.0);

    /* Free the previous array (which both a1 and a2 point to) before overwriting it so that it won't get lost*/

    a2->array = b1->array;

    print_array(a1);
    print_array(a2);
    print_array(a_shallow);
    print_array(a_deep);
    print_array(b1);

    a1->array[0][1] = 5000.0;
    a2->array[1][2] = 6000.0;
    a_shallow->array[2][3] = 7000.0;
    a_deep->array[3][4] = 8000.0;
    b1->array[4][5] = 9000.0;

    print_array(a1);
    print_array(a2);
    print_array(a_shallow);
    print_array(a_deep);
    print_array(b1);

    printf("------------------------------------\n          Question 2d     \n------------------------------------\n\n");

    /*A total of 3 arrays and 4 struct pointers will need to be freed*/
    printf("Arrays to be freed: a_shallow, a_deep, b1\n");
    free_array(a_deep);
    free_array(a1);
    free_array(a_shallow);
    printf("Pointers to be freed separately: a1\n");
    free(b1);

    printf("\n\n\n");

    return 0;
}

