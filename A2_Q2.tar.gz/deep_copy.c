#include "functions.h"

Double_Array* deep_copy (Double_Array* ptr)
{
    Double_Array* copy = NULL;
    int row = ptr->rowsize;
    int col = ptr->colsize;
    int i, j;
    copy = double_array(row, col);

    for (i = 0; i < row; i++)
    {
        for (j = 0; j < col; j++)
        {
            copy->array[i][j] = ptr->array[i][j];
        }
    }

    return copy;
}
