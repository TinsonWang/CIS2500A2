CIS2500 Assignment 2 Part 2 - Due: February 3, 2020
Written by Tinson Wang, 0983887

Files included in this program:
1. a2_q2.c
2. double_array.c
3. rand_double.c
4. randomize_array.c
5. print_array.c
6. free_array.c
7. shallow_copy.c
8. deep_copy.c
9. print_struct.c
10. functions.h
11. Makefile
12. README.txt

Q2b.
The arrays for a1, a2, and a_shallow are the same. The array for a_deep is different.
This is because both a2 and a_shallow point to the same memory location as a1. Therefore, any changes made to this location
through any of a1, a2, or a_shallow will be reflected in each of a1, a2, and a_shallow.

Q2c.
The assignment of a2->array = b1->array will cause the array of a1 BUT NOT a_shallow to change.
This is because a1 and a2 share the same struct address, but a_shallow does not. Therefore, a1, a2, and b1 will point to the same memory location.
Any changes made to this location through any of a1, a2, and b1 will be reflected in each of a1, a2, and b1.
a_shallow and a_deep will each point to different addresses, and changes made to either of these will not be reflected anywhere else.

Q2d.
There are three separate arrays that need to be freed: a1/a2/b1, a_deep, and a_shallow. Since a1/a2/b1 all point to the same address,
calling free_array on any one of a1, a2, or b1 will free one of the three arrays that need to be freed. It is advantageous to call free_array on a1 or b1 though.
This is because a1 and b1 are both dynamically allocated while a2 is not. Calling free_array on either a1 or b1 will also free the pointer.
The other two arrays are each pointed to by a_deep and a_shallow. free_array must be called on both a_deep and a_shallow.
One final variable must be freed and that is either the pointers a1 or b1 (whichever one that was not called using free_array) as it was dynamically allocated.
a2 is a local pointer and therefore does not need to be freed specifically.