#include "functions.h"

void print_struct(Double_Array* ptr, char* string)
{
    printf("%s\n", string);
    printf("struct address = %p\n", ptr);
    printf("row_size = %d, col_size = %d\n", ptr->rowsize, ptr->colsize);
    printf("array address = %p, with contents:\n\n", (ptr->array));

    print_array(ptr);
    printf("\n\n");
}
