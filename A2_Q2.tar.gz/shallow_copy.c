#include <assert.h>
#include <string.h>
#include "functions.h"

Double_Array* shallow_copy(Double_Array* ptr)
{

    Double_Array* copy = NULL;
    copy = malloc(sizeof(Double_Array));
    assert(copy != NULL);
    copy->rowsize = ptr->rowsize;
    copy->colsize = ptr->colsize;
    copy->array = ptr->array;

    int i, j;
    for (i = 0; i < copy->rowsize; i++)
    {
        for (j = 0; j < copy->colsize; j++)
        {
            copy->array[i][j] = ptr->array[i][j];
        }
    }

    return copy;
}
